import React from 'react';

// Component disabled as per request to remove AI assistant
export const AIConsultant: React.FC = () => {
  return null;
};
